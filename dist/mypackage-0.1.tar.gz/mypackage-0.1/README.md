# mypackage
This library was created as an example of how to publish your own Phyton package.

## building this package locally
python setup.py sdist